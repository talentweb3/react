import React, { useContext, useEffect, useLocation } from 'react';
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom';


import UserProfile from './pages/userProfile/UserProfile';
import User from './routes/user';
import Navbar from './components/navbar/Navbar';
import { Dashboard, Welcome, Auth } from './pages';
import { TemplateContext } from './template/TemplateProvider';
import { Grid } from '@mui/material';

const App = () => {
  const ctx = useContext(TemplateContext);

  return (
    <Grid>
      <BrowserRouter>
        {ctx.user ? '' : <Navbar />}
        <Switch>
          {/* <Route exact path= "/pass" component = { () => (<ChangePassword />) } /> */}
          <Route exact path="/" component={() => (!ctx.user ? <Redirect to='/user/login' /> : <Redirect to="/main"/>)} />
          {/* <Route path="/user/:singi"  render={() => <User/>}/> */}
          <Route path="/main" render={() => (ctx.user ? (<Dashboard />) : (<Redirect to="/"/>))}/>
          <Route path="/user/:signin" component={() => (ctx.user ? <Redirect to='/main' /> : <Auth />)} />
          {/* <Route exact path={`${path}/resetPassword/:token`} component={() => (ctx.user ? <Redirect to='/main' /> : <ResetPassword />)} /> */}
          {/* <Route exact path="/me" component={() => (!ctx.user ? <Redirect to='/welcome' /> : <UserProfile />)} /> */}
        </Switch>
      </BrowserRouter>
    </Grid>
  )
}


export default App;