import {
  GET_INFOS_SUCCESS,
  GET_INFO_SUCCESS,
  START_LOADING,
  END_LOADING,
} from '../constants/infoConstants.js';

export const infosReducer = (state = { infos: [], isProgress: true }, action) => {
  switch (action.type) {
      case START_LOADING:
          return { ...state, isProgress: true }
      case END_LOADING:
          return { ...state, isProgress: false }
      case GET_INFOS_SUCCESS:
          return {
              ...state,
              infos: action.payload.data,
          };
      case GET_INFO_SUCCESS:
          return { ...state, info: action.payload.data,};
      default: return state;
  }
}