export const AUTH = "AUTH";
export const LOGOUT = 'LOGOUT';
export const UPDATE_ME = 'UPDATE_ME';

export const SUCCESS = "SUCCESS";
export const WARNING = "WARNING";
export const ERROR = "ERROR";
export const INFO = "INFO";

export const GET_USERLIST = "GET_USERLIST";
export const ADD_NEWUSER = "ADD_NEWUSER";
export const UPDATE_USER = "UPDATE_USER";
export const DELETE_USER = "DELETE_USER";