export const APPLY_SUCCESS = 'APPLY_SUCCESS';
export const APPROVED_SUCCESS = 'APPROVED_SUCCESS';
export const GET_PROPOSALS_SUCCESS = "GET_PROPOSAL_SUCCESS";
export const VIEW_DATA = "VIEW_DATA";

export const SUCCESS = "SUCCESS";
export const WARNING = "WARNING";
export const ERROR = "ERROR";
export const INFO = "INFO";
