import React, { useContext } from 'react'
import { Route, useRouteMatch, Redirect } from 'react-router-dom'
import { Auth, ResetPassword } from '../pages'
import Navbar from '../components/navbar/Navbar';
import { TemplateContext } from '../template/TemplateProvider'

const User = (props) => {
    const { path } = useRouteMatch();
    const ctx = useContext(TemplateContext);

    return (
        <div>
            
        </div>
    )
}

export default User
