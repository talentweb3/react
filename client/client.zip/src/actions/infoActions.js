import * as api from '../apis/api.js';

import {
    GET_INFOS_SUCCESS,
    GET_INFO_SUCCESS,
    START_LOADING,
    END_LOADING,
} from '../constants/infoConstants.js';

export const getInfos = () => async (dispatch) => {
  try {
      dispatch({ type: START_LOADING });
      var data=[];
      data = await api.getInfos();
      dispatch({ type: GET_INFOS_SUCCESS, payload: data });
      dispatch({ type: END_LOADING });
  } catch (error) {
      console.log("backend is not called", error);
  }
}
export const getInfo = (id) => async (dispatch) => {
  try {
      dispatch({ type: START_LOADING });

      const { data } = await api.getInfo(id);
      dispatch({ type: GET_INFO_SUCCESS, payload: data });
      dispatch({ type: END_LOADING });
  } catch (error) {
      console.log(error.response);
  }
}