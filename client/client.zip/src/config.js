let variable = {}


if (process.env.NODE_ENV  === 'production') {
    variable = {
        DB_ROUTE: "https://",
        FRONT_ROUTE: "https://"
    }
} else {
    variable = {
        DB_ROUTE: "http://localhost:8000",
        FRONT_ROUTE: "http://localhost:3000"
    }
}

export default variable