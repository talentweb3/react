import React, { useState, useEffect } from 'react';
import { Box, Typography} from "@mui/material";

const Welcome = () => {
  
  return (
    <Box sx={{marginTop:'50px',  display:'flex', justifyContent:"center", alignItems:'center',height:'100vh'}}>
      <Typography variant="h1" sx={{textAlign:'center', color:"#E20", fontWeight:'700'}}>
           Welcome!!!
      </Typography>
    </Box>
      
  );
};

export default Welcome;
