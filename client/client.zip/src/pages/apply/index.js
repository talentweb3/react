import React from 'react'
import PropTypes from 'prop-types'
import Checkout from './check'

const Apply = (props) => {
    return (
        <div>
            <Checkout/>
        </div>
    )
}

export default Apply;
