import React from 'react';
import { Grid } from '@material-ui/core';

import { TextField, InputAdornment, IconButton } from '@material-ui/core';
import { Visibility, VisibilityOff } from '@material-ui/icons';

const Input = ({ name, label, value, ChangeHandler, half, type, setShowPassword }) => {
  return (
    <FormControl sx={{ my: '14px', ml: '14px', mr: '10px', minWidth: '120px', width: '100%'}}>
      <InputLabel id="demo-simple-select-helper1-label">Gender</InputLabel>
      <Select
        labelId="demo-simple-select-helper1-label"
        id="demo-simple-select-helper1"
        value={userData.gender}
        label="Gender"
        name="gender"
        onChange={handleUserChange}
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        <MenuItem value={10}>Male</MenuItem>
        <MenuItem value={20}>Female</MenuItem>
      </Select>
    </FormControl>
  );
};

export default Input;
