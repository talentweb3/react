import React from 'react';
import { Box } from '@mui/system';
import { TextField } from '@mui/material';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DesktopDatePicker from '@mui/lab/DesktopDatePicker';
import AdapterDateFns from '@mui/lab/AdapterDateFns';

const myDatePicker = ({ name, label, value, ChangeHandler }) => {
  return (
    <Box sx={{ margin:'14px', width:'100%'}}>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <DesktopDatePicker
          name={name}
          label={label}
          value={value}
          onChange={ChangeHandler}
          renderInput={
            (param) => (
              <TextField {...param}
              variant="outlined"
              required
              fullWidth
              />)}
        />
      </LocalizationProvider>
    </Box>
  );
};

export default myDatePicker;
