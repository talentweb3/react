import fs from 'fs';
import mongoose from 'mongoose';
import cloudinary from '../utils/cloudinary.js';
import path from 'path';

import User from '../models/user.js';

import { catchAsync } from '../utils/catchAsync.js';
import AppError from '../utils/appError.js';


export const getInfos = catchAsync(async (req, res, next) => {
    

    const infos = await User.find().sort({ _id: -1 });
    console.log(infos);
    res.status(200).json({
        data: infos,
    });

})
export const getInfo = catchAsync(async (req, res, next) => {
    console.log("req.params:", req.params);
    const id = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(id))
        return next(new AppError('id is not valid', 400));

    const data = await User.findById(id);
    res.status(200).json({ data });

})
