import express from 'express';

const router = express.Router();

import {  getInfos,getInfo } from '../controllers/infosController.js';
import auth, { uploadPostImage, uploadedPostCloudinary } from '../controllers/middleware.js';

router
    .route('/')
    .get(getInfos)
    // .post(auth, uploadPostImage, uploadedPostCloudinary, createPost)
    // .delete(deletePost);

router
    .route('/:id')
    .get(getInfo)
    // .patch(auth, uploadPostImage, uploadedPostCloudinary, updatePost);


export default router;